1. pip install -r requirements.txt
2. python3 bot.py